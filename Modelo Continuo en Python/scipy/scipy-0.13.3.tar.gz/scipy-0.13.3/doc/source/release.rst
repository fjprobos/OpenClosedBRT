*************
Release Notes
*************

.. toctree::
   :maxdepth: 1

   release.0.13.3
   release.0.13.2
   release.0.13.1
   release.0.13.0
   release.0.12.0
   release.0.11.0
   release.0.10.1
   release.0.10.0
   release.0.9.0
   release.0.8.0
   release.0.7.2
   release.0.7.1
   release.0.7.0
