.. include:: ../release/0.13.3-notes.rst
