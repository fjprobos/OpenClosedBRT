.. include:: ../release/0.13.2-notes.rst
