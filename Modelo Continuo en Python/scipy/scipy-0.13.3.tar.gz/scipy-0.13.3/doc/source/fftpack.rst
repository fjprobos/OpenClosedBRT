.. automodule:: scipy.fftpack
